Simko SI for desktop (Windows)
=========================

This opens https://simkosi.com in its own window, like an app, using a browser you already have.
It does not install a browser and does not run anything on your computer except this launcher.
Sign in once in the window and you stay signed in.

1. Unzip this folder (right-click, Extract All).
2. Double-click "Install Simko SI.cmd". If Windows shows "Windows protected your PC", choose More info, then Run anyway.
   It adds Simko SI to your Start menu and desktop and opens it.
   Or just double-click "Simko SI.cmd" to open it once without installing.
To remove: delete "Simko SI" from the Start menu and desktop, and the folder %LOCALAPPDATA%\SimkoSI.

This launcher is not code-signed, so your computer will warn you the first time. That is expected.
The simplest option needs no download at all: open https://simkosi.com in Chrome or Edge and choose Install.
More help: https://simkosi.com/download
