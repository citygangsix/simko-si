# Adds Simko SI to the Start menu and the desktop. Opens https://simkosi.com in an Edge app window.
$ErrorActionPreference = 'Stop'
$url = 'https://simkosi.com/?source=desktop'
$dir = Join-Path $env:LOCALAPPDATA 'SimkoSI'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
Copy-Item -Force (Join-Path $PSScriptRoot 'simkosi.ico') (Join-Path $dir 'simkosi.ico')
$browser = $null
foreach ($k in @('msedge.exe', 'chrome.exe', 'brave.exe')) {
  foreach ($hive in @('HKCU:', 'HKLM:')) {
    $p = "$hive\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$k"
    if (-not $browser -and (Test-Path $p)) { $browser = (Get-ItemProperty $p).'(default)' }
  }
}
$shell = New-Object -ComObject WScript.Shell
foreach ($folder in @([Environment]::GetFolderPath('Programs'), [Environment]::GetFolderPath('Desktop'))) {
  $lnk = $shell.CreateShortcut((Join-Path $folder 'Simko SI.lnk'))
  if ($browser) { $lnk.TargetPath = $browser; $lnk.Arguments = "--app=$url" }
  else { $lnk.TargetPath = $url }
  $lnk.IconLocation = (Join-Path $dir 'simkosi.ico')
  $lnk.Description = 'Simko SI'
  $lnk.Save()
}
Write-Host 'Simko SI was added to your Start menu and desktop.'
Start-Process -FilePath $(if ($browser) { $browser } else { $url }) -ArgumentList $(if ($browser) { "--app=$url" } else { @() })
