@echo off
rem Opens Simko SI in its own window (Microsoft Edge app mode).
start "" msedge --app="https://simkosi.com/?source=desktop"
if errorlevel 1 start "" "https://simkosi.com/?source=desktop"
