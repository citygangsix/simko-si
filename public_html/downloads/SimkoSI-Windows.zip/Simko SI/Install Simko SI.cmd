@echo off
rem Double-click to add Simko SI to the Start menu and desktop.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install Simko SI.ps1"
pause
