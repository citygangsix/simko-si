Simko SI for desktop (Linux)
=========================

This opens https://simkosi.com in its own window, like an app, using a browser you already have.
It does not install a browser and does not run anything on your computer except this launcher.
Sign in once in the window and you stay signed in.

1. Extract: tar xzf simkosi-linux.tar.gz
2. Run: ./simkosi-linux/install.sh   (installs for your user only, no sudo)
   Or run ./simkosi-linux/simkosi to open it once.
To remove: rm ~/.local/bin/simkosi ~/.local/share/applications/simkosi.desktop

This launcher is not code-signed, so your computer will warn you the first time. That is expected.
The simplest option needs no download at all: open https://simkosi.com in Chrome or Edge and choose Install.
More help: https://simkosi.com/download
