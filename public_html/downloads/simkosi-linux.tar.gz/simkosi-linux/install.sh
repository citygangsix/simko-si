#!/bin/sh
# Installs the Simko SI launcher for this user only (no sudo).
set -e
here="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications" "$HOME/.local/share/icons/hicolor/512x512/apps"
install -m 755 "$here/simkosi" "$HOME/.local/bin/simkosi"
install -m 644 "$here/simkosi.png" "$HOME/.local/share/icons/hicolor/512x512/apps/simkosi.png"
sed "s#^Exec=simkosi#Exec=$HOME/.local/bin/simkosi#" "$here/simkosi.desktop" > "$HOME/.local/share/applications/simkosi.desktop"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$HOME/.local/share/applications" || true
echo "Simko SI is installed. Find it in your app menu, or run: simkosi"
