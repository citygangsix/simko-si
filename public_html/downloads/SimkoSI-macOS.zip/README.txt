Simko SI for desktop (Mac)
=========================

This opens https://simkosi.com in its own window, like an app, using a browser you already have.
It does not install a browser and does not run anything on your computer except this launcher.
Sign in once in the window and you stay signed in.

1. Double-click the zip to unzip it, then drag "Simko SI" into your Applications folder.
2. The first time, right-click (or Control-click) "Simko SI" and choose Open, then Open again.
   macOS says it cannot check the developer because this launcher is not signed. If there is no Open button,
   go to System Settings > Privacy & Security and choose Open Anyway.
It opens Simko SI in a Chrome, Edge or Brave app window if you have one, otherwise in Safari.
Safari users on macOS Sonoma or later can also use File > Add to Dock on simkosi.com instead.

This launcher is not code-signed, so your computer will warn you the first time. That is expected.
The simplest option needs no download at all: open https://simkosi.com in Chrome or Edge and choose Install.
More help: https://simkosi.com/download
